# Ekklesia — Church Handoff

Start in **docs/** then run the app.

- docs/1-Developer-Handoff.md — read first (architecture, conventions, file map)
- docs/2-Setup-Instructions.md — set up Supabase + run + deploy
- docs/3-Requirements-PRD.md — what the product is and should do
- docs/4-Build-and-Prompts-Guide.md — design system + reusable AI prompts to continue
- docs/5-Launch-Tasks.md — full task checklist (if present)

Code:
- ekklesia-app/ — Next.js 14 + Supabase front end (build verified: tsc clean, next build passes)
- ekklesia-backend/ — SQL migrations, data layer, address routes, setup notes

This handoff covers the CHURCH side. The pastor app is separate.
